import torch
import torch.nn as nn
import torch.nn.functional as f


class Emotion(nn.Module):
    def __init__(self):
        super(Emotion, self).__init__()
        pass
