# global definition
UNK_TOKEN = "<unk>"
PAD_TOKEN = "<pad>"
BOS_TOKEN = "<bos>"
EOS_TOKEN = "<eos>"
SI_TOKEN = "<si>"
SI_IDX, PAD_IDX, UNK_IDX, BOS_IDX, EOS_IDX = 0, 1, 2, 3, 4
SPECIAL_SYMBOLS = ['<si>', '<pad>', '<unk>', '<bos>', '<eos>']
WORD_MASK = "<mask>"
