import torch
import os
import yaml
import argparse
from transformers import AutoTokenizer
import numpy as np
import random
import torch.backends.cudnn as cudnn
from test_dataset import S2TDataset
from torch.utils.data import DataLoader
from model.slr_clip import SLRCLIP



def main(argus, conf):
    # 获取设备
    device = torch.device(args.device)

    # 设置随机种子
    seed = args.seed
    torch.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)

    cudnn.benchmark = False

    # 数据集准备
    print(f"Creating dataset:")
    tokenizer = AutoTokenizer.from_pretrained(config['model']['tokenizer'])

    # 练练数据
    train_data = S2TDataset(path=config['data']['train_label_path'], tokenizer=tokenizer, config=config, args=args,
                            phase='train')
    train_dataloader = DataLoader(train_data,
                                  batch_size=args.batch_size,
                                  num_workers=args.num_workers,
                                  collate_fn=train_data.collate_fn,
                                  pin_memory=args.pin_mem,
                                  drop_last=True)

    # 验证数据
    dev_data = S2TDataset(path=config['data']['dev_label_path'], tokenizer=tokenizer, config=config, args=args,
                          phase='val')

    dev_dataloader = DataLoader(dev_data,
                                batch_size=args.batch_size,
                                num_workers=args.num_workers,
                                collate_fn=dev_data.collate_fn,
                                pin_memory=args.pin_mem)

    # 测试数据
    test_data = S2TDataset(path=config['data']['test_label_path'], tokenizer=tokenizer, config=config, args=args,
                           phase='test')
    test_dataloader = DataLoader(test_data,
                                 batch_size=args.batch_size,
                                 num_workers=args.num_workers,
                                 collate_fn=test_data.collate_fn,
                                 pin_memory=args.pin_mem)

    model = SLRCLIP(config=config)
    model.to(device)

    pass


if __name__ == '__main__':
    # 禁用分词器的并行处理
    os.environ["TOKENIZERS_PARALLELISM"] = "false"
    parser = argparse.ArgumentParser('VLP scripts', parents=[get_args_parser()])
    args = parser.parse_args()
    print(args)

    with open(args.config, 'r+', encoding='utf-8') as f:
        config = yaml.load(f, Loader=yaml.FullLoader)

    main(vars(args), config)
