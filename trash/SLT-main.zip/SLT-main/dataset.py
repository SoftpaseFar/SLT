import torch
from torch.utils.data import Dataset
from torchvision import transforms
from PIL import Image
import utils
from vidaug import augmentors as va
from augmentation import *
from definition import *
import cv2
from torch.nn.utils.rnn import pad_sequence


# 数据集加载
class CSLDailyDataset(Dataset):
    def __init__(self, tokenizer, config, args, phase, training_refurbish=False):
        # 配置项
        self.config = config
        self.args = args
        self.training_refurbish = training_refurbish
        self.tokenizer = tokenizer
        self.phase = phase

        self.raw_data = utils.load_dataset(config, phase)
        self.img_path = config['data']['img_path']
        self.max_length = config['data']['max_length']
        
