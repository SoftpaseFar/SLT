import os
import torch
import yaml
import argparse
from pathlib import Path
from transformers import MBartForConditionalGeneration, MBartTokenizer, MBartConfig
import numpy as np
import random
from dataset import CSLDailyDataset
import torch.backends.cudnn as cudnn
from torch.utils.data import DataLoader


def get_args_parser():
    a_parser = argparse.ArgumentParser('VLP scripts', add_help=False)
    a_parser.add_argument('--batch-size', default=16, type=int)
    a_parser.add_argument('--epochs', default=10, type=int)
    a_parser.add_argument('--config', type=str, default='./config.yaml')
    a_parser.add_argument('--device', default='cuda')
    a_parser.add_argument('--resize', default=256, type=int)
    a_parser.add_argument('--seed', default=0, type=int)
    a_parser.set_defaults(pin_mem=True)
    a_parser.add_argument('--num_workers', default=8, type=int)
    a_parser.add_argument('--output_dir', default='./output/test/o_1')
    return a_parser


def main(args, config):
    # 获取设备
    device = torch.device(args['device'])
    print(device)

    # 设置随机种子
    seed = args['seed']
    torch.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)
    # 禁用CUDA自动调优，使实验结果一致
    # cudnn.benchmark = False

    # 加载分词器
    tokenizer = MBartTokenizer.from_pretrained(config['model']['tokenizer'])
    print(tokenizer('I love you'))

    # 加载训练数据集
    train_data = CSLDailyDataset(tokenizer=tokenizer, config=config, args=args, phase='train', training_refurbish=True)
    print(train_data)


if __name__ == '__main__':
    # 禁用分词器的并行处理
    os.environ["TOKENIZERS_PARALLELISM"] = "false"

    # 加载参数
    parser = argparse.ArgumentParser('VLP scripts', parents=[get_args_parser()])
    args = parser.parse_args()
    with open(args.config, 'r+', encoding='utf-8') as f:
        config = yaml.load(f, Loader=yaml.FullLoader)

    # 创建输出文件夹
    if args.output_dir:
        Path(args.output_dir).mkdir(parents=True, exist_ok=True)

    # 开始训练
    main(vars(args), config)
